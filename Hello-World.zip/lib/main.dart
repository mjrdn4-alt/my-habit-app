import 'package:flutter/material.dart';

void main() {
  runApp(const HabitTrackerApp());
}

class HabitTrackerApp extends StatelessWidget {
  const HabitTrackerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Habit Tracker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2E7D32)),
        useMaterial3: true,
      ),
      home: const HabitScheduleScreen(),
    );
  }
}

class Habit {
  final String id;
  final String title;
  final TimeOfDay scheduledTime;
  final int durationMinutes;
  int streak;
  bool isCompletedToday;

  Habit({
    required this.id,
    required this.title,
    required this.scheduledTime,
    required this.durationMinutes,
    this.streak = 0,
    this.isCompletedToday = false,
  });
}

class HabitScheduleScreen extends StatefulWidget {
  const HabitScheduleScreen({super.key});

  @override
  State<HabitScheduleScreen> createState() => _HabitScheduleScreenState();
}

class _HabitScheduleScreenState extends State<HabitScheduleScreen> {
  final List<Habit> _habits = [
    Habit(
      id: '1',
      title: 'Morning Workout & Cycling',
      scheduledTime: const TimeOfDay(hour: 6, minute: 0),
      durationMinutes: 45,
      streak: 5,
      isCompletedToday: false,
    ),
    Habit(
      id: '2',
      title: 'Study & Reading',
      scheduledTime: const TimeOfDay(hour: 20, minute: 0),
      durationMinutes: 30,
      streak: 2,
      isCompletedToday: false,
    ),
  ];

  void _toggleHabit(String id) {
    setState(() {
      final habit = _habits.firstWhere((h) => h.id == id);
      habit.isCompletedToday = !habit.isCompletedToday;
      if (habit.isCompletedToday) {
        habit.streak += 1;
      } else {
        habit.streak = (habit.streak > 0) ? habit.streak - 1 : 0;
      }
    });
  }

  void _addNewHabit(String title, TimeOfDay time, int duration) {
    setState(() {
      _habits.add(
        Habit(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          title: title,
          scheduledTime: time,
          durationMinutes: duration,
        ),
      );
    });
  }

  void _showAddHabitDialog() {
    final titleController = TextEditingController();
    TimeOfDay selectedTime = const TimeOfDay(hour: 7, minute: 0);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom + 20,
                left: 20,
                right: 20,
                top: 24,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Add Habit', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  TextField(
                    controller: titleController,
                    decoration: const InputDecoration(labelText: 'Habit Title', border: OutlineInputBorder()),
                  ),
                  const SizedBox(height: 12),
                  ListTile(
                    title: Text('Time: ${selectedTime.format(context)}'),
                    trailing: const Icon(Icons.access_time),
                    onTap: () async {
                      final picked = await showTimePicker(context: context, initialTime: selectedTime);
                      if (picked != null) setModalState(() => selectedTime = picked);
                    },
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        if (titleController.text.trim().isNotEmpty) {
                          _addNewHabit(titleController.text.trim(), selectedTime, 30);
                          Navigator.pop(ctx);
                        }
                      },
                      child: const Text('Save'),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Habit Tracker')),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddHabitDialog,
        child: const Icon(Icons.add),
      ),
      body: ListView.builder(
        itemCount: _habits.length,
        itemBuilder: (context, index) {
          final habit = _habits[index];
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            child: ListTile(
              leading: Text(habit.scheduledTime.format(context), style: const TextStyle(fontWeight: FontWeight.bold)),
              title: Text(habit.title),
              subtitle: Text('Streak: ${habit.streak} days'),
              trailing: Checkbox(
                value: habit.isCompletedToday,
                onChanged: (_) => _toggleHabit(habit.id),
              ),
            ),
          );
        },
      ),
    );
  }
}
